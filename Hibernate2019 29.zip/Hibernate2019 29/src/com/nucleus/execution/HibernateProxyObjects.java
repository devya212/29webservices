package com.nucleus.execution;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;

public class HibernateProxyObjects {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();		
		
		//Student student=(Student)session.get(Student.class, 1);
		Student student=(Student)session.load(Student.class, 1);
		System.out.println(student.getStudentId());		
		//System.out.println(student.getSubjects().get(0).getSubName());
		session.close();		
		Session session2=sessionFactory.openSession();
		System.out.println(student.getStudentId());
		System.out.println(student.getSubjects().get(0).getSubName());
		session2.close();
		sessionFactory.close();

	}

}
