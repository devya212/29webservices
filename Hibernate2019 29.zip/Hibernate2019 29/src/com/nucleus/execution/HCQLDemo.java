package com.nucleus.execution;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.OrderBy;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;
import com.nucleus.pojo.Address;


public class HCQLDemo {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
	Criteria criteria=session.createCriteria(Subject.class);
	//System.out.println(criteria.list());
	criteria.addOrder(Order.desc("subName"));
	System.out.println(criteria.list());
		
		transaction.commit();
		session.close();
		sessionFactory.close();
}
}
