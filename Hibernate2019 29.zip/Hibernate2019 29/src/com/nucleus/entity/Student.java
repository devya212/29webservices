package com.nucleus.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.nucleus.pojo.Address;

@Entity
@Table(name="Student0")
public class Student {
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)//(mappedBy="student")
	@JoinTable(name="Stud_Subj",joinColumns=@JoinColumn(name="studentid"),
	inverseJoinColumns=@JoinColumn(name="subjectid"))
	private List<Subject> subjects;
	
	/*@OneToOne
	private Subject subject;
	
	
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}*/
	
public List<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}
/*@Embedded
	Address address;
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
 */	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	@Column(name="studid")
private int studentId;
	@Column(name="sname", length=20, nullable=false,unique=true)
private String studentName;
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}

}
